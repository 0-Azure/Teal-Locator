/* This is a bot Made Using mineflayer, made by Tahmeed Afif, 
main directive is at line 82 ,
this bot can, speak, follow a certain player or locate a specefic block,
this bad boy can even mine and place blocks to get to its desired location,

to make this bot work, (if you downloaded this index.json file)
put it in a folder, fire up your terminal, (it need node.js and internet connection to work)
type npm -init
then type npm install mineflayer,

after everything is done, put your server information in line 29-33 ((if you have a server, type in the server address
in the host field and delete the port line, if you dont have a server, put set the host to 'localhost' and open 
minecraft, open up a singleplayer world then in the esc menu, click open to LAN, put the number it gives you in 
chat in the port field))

then change the username of the player you want it to follow at line 38 

btw you can customize this however you want, be sure to notice that things can get a little wonky

then to make the bot join your world open the terminal one more time then type node index.js

*/

const mineflayer = require('mineflayer')
const { pathfinder, Movements, goals } = require('mineflayer-pathfinder')
const GoalFollow = goals.GoalFollow
const GoalBlock = goals.GoalBlock

const bot = mineflayer.createBot({
    host: 'localhost',
    port: 57933,
    username: 'Teal_Locator'
})

bot.loadPlugin(pathfinder)

function followPlayer() {
    const playerAz = bot.players['xXAzurePlayzXx']

    if (!playerAz || !playerAz.entity) {
        bot.chat("I can't see Azure!")
        return
    }

    const mcData = require('minecraft-data')(bot.version)
    const movements = new Movements(bot, mcData)
    movements.scafoldingBlocks = []

    bot.pathfinder.setMovements(movements)

    const goal = new GoalFollow(playerAz.entity, 1)
    bot.pathfinder.setGoal(goal, true)
}

function locateEmeraldBlock () {
    const mcData = require('minecraft-data')(bot.version)
    const movements = new Movements(bot, mcData)
    movements.scafoldingBlocks = []
    bot.pathfinder.setMovements(movements)

    const emeraldBlock = bot.findBlock({
        matching: mcData.blocksByName.emerald_block.id,
        maxDistance: 32
    })

    if (!emeraldBlock) {
        bot.chat("I can't see any emerald blocks!")
        return
    }

    const x = emeraldBlock.position.x
    const y = emeraldBlock.position.y + 1
    const z = emeraldBlock.position.z
    const goal = new GoalBlock(x, y, z)
    bot.pathfinder.setGoal(goal)
}

function Greeting() {
    bot.chat("Hello Everyone!, I am the Personal following Assistant AI for xXAzurePlayzXx, coded in JavaScript, nice to meet you!");
}

bot.once('spawn', followPlayer, Greeting)